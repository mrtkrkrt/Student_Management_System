const express = require('express');
const mongoose = require('mongoose');
const fileUpload = require('express-fileupload');
const pdf_parse = require('pdf-parse');
const pdf_dist = require('pdfjs-dist/legacy/build/pdf.js');
const ejs = require('ejs');
const path = require('path');
const fs = require('fs');

const app = express();
const port = 3000;

var MongoClient = require('mongodb').MongoClient;
var url =
    'mongodb+srv://admin:a@muratkarakurt.9ergo.mongodb.net/myFirstDatabase?retryWrites=true&w=majority';
let db = 0,
    username_temp = '',
    id_temp = '';

app.use('/public', express.static('public/'));
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(fileUpload());

app.get('/', async (req, res) => {
    res.render('choose');
});

app.get('/login_user', async (req, res) => {
    db = 0;
    let text = '';
    res.render('login', { text });
});

app.get('/login_admin', async (req, res) => {
    db = 1;
    let text = '';
    username_temp = '';
    id_temp = '';
    res.render('login', { text });
});

app.get('/admin_page/:id', async (req, res) => {
    let username = req.query.username,
        id = String(req.url).split('/')[1];
    res.render('admin_page', {
        username: username,
        id: id,
    });
});

app.post('/analyse_file', (req, res) => {
    const path = 'public/uploads';
    if (!fs.existsSync(path)) fs.mkdirSync(path);
    let uploadedPDF = req.files.pdf;
    let PdfPath =
        'C:/Users/mrtkr/Desktop/Deneme' + '/public/uploads/' + uploadedPDF.name;
    uploadedPDF.mv(PdfPath);

    res.redirect('/user_page/' + id_temp + '/?username=' + username_temp);
});

app.get('/user_page/:id', async (req, res) => {
    let username = req.query.username,
        id = String(req.url).split('/')[1];
    res.render('user_page', {
        username: username,
        id: id,
    });
});

app.post('/middleware', async (req, res) => {
    let text = '',
        username = req.body.username,
        password = req.body.password,
        user_info;
    db_nm = db == 1 ? 'admin' : 'user';
    if (username && password) {
        let promise = new Promise((resolve, reject) => {
            MongoClient.connect(url, function (err, db) {
                if (err) throw err;
                var dbo = db.db('mydb');
                dbo.collection(db_nm)
                    .find({ username: username, password: password })
                    .toArray(function (err, result) {
                        if (err) throw err;
                        db.close();
                        if (result.length == 0) {
                            reject();
                        } else {
                            username_temp = result[0]['username'];
                            user_info = result[0];
                            id = String(result[0]._id);
                            id_temp = id;
                            resolve('');
                        }
                    });
            });
        })
            .then(() => {
                db == 1
                    ? res.redirect(
                          '/admin_page/' +
                              id +
                              '/?username=' +
                              user_info['username']
                      )
                    : res.redirect(
                          '/user_page/' +
                              id +
                              '/?username=' +
                              user_info['username']
                      );
            })
            .catch(() => {
                text = 'Wrong Attempt!';
                res.render('login', { text });
            });
    } else {
        text = 'Information cannot be empty.';
        res.render('login', { text });
    }
});

app.listen(port);
