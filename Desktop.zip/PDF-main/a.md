* admin sorgu 1
* admin sorgu 2