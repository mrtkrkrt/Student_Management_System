const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const UserSchema = new Schema({
    username: String,
    password : String,
    dateCreated: {
        type: Date,
        default: Date.now,
    },
});

const user = mongoose.model('UserSchema', UserSchema);
module.exports = user;